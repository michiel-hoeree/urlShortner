text = "the quick brown fox"
print(text[1:5])